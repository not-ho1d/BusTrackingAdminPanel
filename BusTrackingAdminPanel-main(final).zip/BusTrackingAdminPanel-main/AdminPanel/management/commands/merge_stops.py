from django.core.management.base import BaseCommand
from AdminPanel.models import Stops


class Command(BaseCommand):
    help = "Merge duplicate stops dynamically"

    def handle(self, *args, **kwargs):

        stop_names = Stops.objects.values_list(
            "stop_name",
            flat=True
        ).distinct()

        total_merged = 0
        total_deleted = 0

        for stop_name in stop_names:

            stops = Stops.objects.filter(stop_name=stop_name)

            if stops.count() <= 1:
                continue

            main_stop = stops.first()

            merged_routes = []

            for stop in stops:

                if stop.parent_routes:

                    for route in stop.parent_routes:

                        if route not in merged_routes:
                            merged_routes.append(route)

            main_stop.parent_routes = merged_routes
            main_stop.save()

            duplicates = stops.exclude(id=main_stop.id)

            deleted_count = duplicates.count()

            duplicates.delete()

            total_deleted += deleted_count
            total_merged += 1

            self.stdout.write(
                self.style.SUCCESS(
                    f"Merged stop: {stop_name} "
                    f"({deleted_count} duplicates removed)"
                )
            )

        self.stdout.write(
            self.style.SUCCESS(
                f"\nFinished.\n"
                f"Stops merged: {total_merged}\n"
                f"Duplicates removed: {total_deleted}"
            )
        )