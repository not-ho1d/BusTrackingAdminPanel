from AdminPanel.models import Bus
from django.core.management.base import BaseCommand
import statistics
import copy

MIN_FEEDBACKS = 5
OUTLIER_LIMIT = 10


def to_minutes(t):
    h, m = map(int, t.split(":"))
    return h * 60 + m


def to_time(m):
    return f"{m // 60:02d}:{m % 60:02d}"


def remove_outliers(offsets):

    if len(offsets) < 3:
        return offsets

    median = statistics.median(offsets)

    filtered = []

    for x in offsets:

        if abs(x - median) <= OUTLIER_LIMIT:
            filtered.append(x)

    return filtered


def apply_feedback(base_timetable, feedbacks):

    timetable = copy.deepcopy(base_timetable)

    grouped = {}

    changed = []

    # group feedbacks
    for fb in feedbacks:

        # ignore old corrupted format
        if "offset" not in fb:
            continue

        key = (fb["trip"], fb["stop"])

        if key not in grouped:
            grouped[key] = []

        grouped[key].append(fb["offset"])

    # apply feedback
    for (trip, stop), offsets in grouped.items():

        if len(offsets) < MIN_FEEDBACKS:
            continue

        original_offsets = offsets.copy()

        offsets = remove_outliers(offsets)

        if not offsets:
            continue

        median_offset = round(statistics.median(offsets))

        original_time = timetable[trip][stop]

        new_minutes = to_minutes(original_time) + median_offset

        updated_time = to_time(new_minutes)

        timetable[trip][stop] = updated_time

        changed.append({
            "trip": trip,
            "stop": stop,
            "before": original_time,
            "after": updated_time,
            "median_offset": median_offset,
            "used_feedbacks": len(offsets),
            "total_feedbacks": len(original_offsets)
        })

    return timetable, changed


def repair_trip_order(timetable):

    repairs = []

    for trip in timetable:

        stops = list(timetable[trip].keys())

        times = []

        for stop in stops:
            times.append(to_minutes(timetable[trip][stop]))

        # forward repair
        for i in range(1, len(times)):

            if times[i] <= times[i - 1]:

                old = times[i]

                times[i] = times[i - 1] + 1

                repairs.append({
                    "trip": trip,
                    "stop": stops[i],
                    "before": to_time(old),
                    "after": to_time(times[i]),
                    "reason": "forward_collision"
                })

        # backward smoothing
        for i in range(len(times) - 2, -1, -1):

            gap = times[i + 1] - times[i]

            if gap <= 0:

                old = times[i]

                times[i] = times[i + 1] - 1

                repairs.append({
                    "trip": trip,
                    "stop": stops[i],
                    "before": to_time(old),
                    "after": to_time(times[i]),
                    "reason": "reverse_collision"
                })

        # save back
        for i, stop in enumerate(stops):
            timetable[trip][stop] = to_time(times[i])

    return timetable, repairs


class Command(BaseCommand):

    def handle(self, *args, **kwargs):

        buses = Bus.objects.all()

        for b in buses:

            feedbacks = b.feedback_timetables or []

            if len(feedbacks) < MIN_FEEDBACKS:
                continue

            updated, changed = apply_feedback(
                b.timetable,
                feedbacks
            )

            updated, repairs = repair_trip_order(updated)

            print("\n==============================")
            print("BUS:", b.bus_name)
            print("==============================")

            print("\nUPDATED STOPS:\n")

            if not changed:
                print("No timetable changes")
            else:

                for c in changed:

                    print(
                        f"[{c['trip']}] "
                        f"{c['stop']} : "
                        f"{c['before']} -> {c['after']} | "
                        f"offset={c['median_offset']} | "
                        f"feedbacks={c['used_feedbacks']}/{c['total_feedbacks']}"
                    )

            print("\nREPAIRS:\n")

            if not repairs:
                print("No repairs needed")
            else:

                for r in repairs:

                    print(
                        f"[{r['trip']}] "
                        f"{r['stop']} : "
                        f"{r['before']} -> {r['after']} | "
                        f"{r['reason']}"
                    )

            b.timetable = updated
            b.feedback_timetables = []

            b.save()

            print("\nFINAL TIMETABLE:\n")
            print(updated)