from django.core.management.base import BaseCommand
from AdminPanel.models import Routes
import math


# =========================================================
# DISTANCE CHECK
# =========================================================

def is_within_30m(coord_lat, coord_lng, end_lat, end_lng):

    coord_lat = float(coord_lat)
    coord_lng = float(coord_lng)

    end_lat = float(end_lat)
    end_lng = float(end_lng)

    R = 6371000

    lat1 = math.radians(coord_lat)
    lat2 = math.radians(end_lat)

    dlat = math.radians(end_lat - coord_lat)
    dlng = math.radians(end_lng - coord_lng)

    a = (
        math.sin(dlat / 2) ** 2
        + math.cos(lat1)
        * math.cos(lat2)
        * math.sin(dlng / 2) ** 2
    )

    c = 2 * math.atan2(
        math.sqrt(a),
        math.sqrt(1 - a)
    )

    distance = R * c

    return distance <= 150


# =========================================================
# COMMAND
# =========================================================

class Command(BaseCommand):

    help = "Generate stop-to-stop route segments"

    def handle(self, *args, **kwargs):

        routes = Routes.objects.all()

        for route in routes:

            print("\n========================")
            print("ROUTE:", route.route_name)
            print("========================")

            route_coords = route.route_coords or []
            stops = route.stopsData or []

            if not route_coords:

                print("No route coords")
                continue

            if len(stops) < 2:

                print("Not enough stops")
                continue

            # =================================================
            # FORWARD SEGMENTS
            # =================================================

            forward_segments = []

            current_coord_index = 0

            for stop_index in range(len(stops) - 1):

                start_stop = stops[stop_index]
                end_stop = stops[stop_index + 1]

                segment_name = (
                    f"{start_stop['name']}-"
                    f"{end_stop['name']}"
                )

                print(
                    "\nLOOKING FOR:",
                    segment_name
                )

                segment_coords = []

                found = False

                for coord_index in range(
                    current_coord_index,
                    len(route_coords)
                ):

                    coord = route_coords[coord_index]

                    segment_coords.append({
                        "lat": coord["lat"],
                        "lng": coord["lng"]
                    })

                    reached = is_within_30m(
                        coord["lat"],
                        coord["lng"],
                        end_stop["lat"],
                        end_stop["lng"]
                    )

                    if reached:

                        print(
                            "FOUND:",
                            segment_name,
                            "| coords:",
                            len(segment_coords)
                        )

                        forward_segments.append({

                            "name": segment_name,

                            "start": start_stop["name"],

                            "end": end_stop["name"],

                            "coords": segment_coords
                        })

                        current_coord_index = (
                            coord_index + 1
                        )

                        found = True

                        break

                if not found:

                    print(
                        "FAILED:",
                        segment_name
                    )

            # =================================================
            # REVERSE SEGMENTS
            # =================================================

            reverse_segments = []

            for segment in forward_segments:

                reverse_segments.append({

                    "name":
                    f"{segment['end']}-{segment['start']}",

                    "start": segment["end"],

                    "end": segment["start"],

                    "coords": list(
                        reversed(segment["coords"])
                    )
                })

                        

            # =================================================
            # SAVE
            # =================================================

            route.stop_to_stop_coords = (
                forward_segments
            )

            route.stop_to_stop_coords_rev = (
                reverse_segments
            )

            route.save()

            # =================================================
            # DEBUG
            # =================================================

            print("\n========================")
            print("FORWARD SEGMENTS")
            print("========================")

            for seg in forward_segments:

                print(
                    seg["name"],
                    "->",
                    len(seg["coords"]),
                    "coords"
                )

            print("\n========================")
            print("REVERSE SEGMENTS")
            print("========================")

            for seg in reverse_segments:

                print(
                    seg["name"],
                    "->",
                    len(seg["coords"]),
                    "coords"
                )

            print("\nSaved successfully")