from django.core.management.base import BaseCommand
from AdminPanel.models import Bus, BusLocation


class Command(BaseCommand):

    help = "Remove BusLocation entries that do not exist in Bus table"

    def handle(self, *args, **kwargs):

        valid_buses = set(
            Bus.objects.values_list(
                "bus_name",
                flat=True
            )
        )

        deleted_count = 0

        for bl in BusLocation.objects.all():

            if bl.bus_name not in valid_buses:

                print(f"Deleting: {bl.bus_name}")

                bl.delete()

                deleted_count += 1

        print(f"\nDeleted {deleted_count} invalid BusLocation entries")