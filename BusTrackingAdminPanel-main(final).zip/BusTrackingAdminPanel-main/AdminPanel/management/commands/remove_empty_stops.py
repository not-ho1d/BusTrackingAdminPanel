from django.core.management.base import BaseCommand
from AdminPanel.models import Stops


class Command(BaseCommand):

    def handle(self, *args, **kwargs):

        Stops.objects.filter(parent_routes=[]).delete()

        print("done")