from django.core.management.base import BaseCommand
from django.core.management import call_command

from AdminPanel.models import (
    Bus,
    BusLocation,
    Routes
)

import json
import time
import math
import traceback

from datetime import (
    datetime,
    timedelta
)

import requests


# =========================================================
# FILES
# =========================================================

CONF_FILE = "conf.json"

GLOBAL_FILE = "global_dat.json"


# =========================================================
# CLOCK
# =========================================================

class SimulationClock:

    def __init__(self):

        self.load_config()

        if self.real_time == 1:

            self.current_time = datetime.now()

        else:

            self.current_time = (
                self.parse_time(
                    self.clock_start_time
                )
            )

        self.write_global()

    def parse_time(self, t):

        try:

            return datetime.strptime(
                t,
                "%H:%M:%S"
            )

        except:

            return datetime.strptime(
                t,
                "%H:%M"
            )

    def load_config(self):

        with open(CONF_FILE, "r") as f:

            conf = json.load(f)

        self.real_time = int(
            conf.get(
                "real_time",
                0
            )
        )

        self.clock_start_time = conf.get(
            "clock_start_time",
            "06:29"
        )

        self.clock_update_interval = float(
            conf.get(
                "clock_update_time",
                0.1
            )
        )

        self.simulation_speed = float(
            conf.get(
                "speed",
                1
            )
        )

    def tick(self):

        self.load_config()

        if self.real_time == 1:

            self.current_time = datetime.now()

        else:

            self.current_time = (
                self.current_time
                +
                timedelta(
                    seconds=float(
                        self.simulation_speed
                    )
                )
            )

        self.write_global()

        time.sleep(
            self.clock_update_interval
        )

    def hhmm(self):

        return (
            f"{self.current_time.hour:02}:"
            f"{self.current_time.minute:02}"
        )

    def full(self):

        return (
            f"{self.current_time.hour:02}:"
            f"{self.current_time.minute:02}:"
            f"{self.current_time.second:02}."
            f"{int(self.current_time.microsecond / 1000):03}"
        )

    def write_global(self):

        data = {
            "time": self.hhmm(),
            "full_time": self.full()
        }

        with open(GLOBAL_FILE, "w") as f:

            json.dump(
                data,
                f,
                indent=4
            )


# =========================================================
# TIME
# =========================================================

def hhmm_to_seconds(t):

    h, m = map(
        int,
        t.split(":")
    )

    return (
        (h * 3600)
        +
        (m * 60)
    )


def full_to_seconds(t):

    h, m, s = t.split(":")

    seconds = float(s)

    return (
        (int(h) * 3600)
        +
        (int(m) * 60)
        +
        seconds
    )


# =========================================================
# DISTANCE
# =========================================================

def point_distance(p1, p2):

    return math.sqrt(
        (
            (p2["lat"] - p1["lat"]) ** 2
        )
        +
        (
            (p2["lng"] - p1["lng"]) ** 2
        )
    )


def get_live_coord(
    coords,
    progress
):

    if not coords:
        return None

    if len(coords) == 1:
        return coords[0]

    total_distance = 0

    distances = []

    for i in range(
        len(coords) - 1
    ):

        dist = point_distance(
            coords[i],
            coords[i + 1]
        )

        distances.append(dist)

        total_distance += dist

    target_distance = (
        total_distance * progress
    )

    travelled = 0

    for i, dist in enumerate(
        distances
    ):

        if (
            travelled + dist
            >=
            target_distance
        ):

            remaining = (
                target_distance
                -
                travelled
            )

            blend = (
                remaining / dist
            )

            p1 = coords[i]

            p2 = coords[i + 1]

            lat = (
                p1["lat"]
                +
                (
                    (
                        p2["lat"]
                        -
                        p1["lat"]
                    )
                    *
                    blend
                )
            )

            lng = (
                p1["lng"]
                +
                (
                    (
                        p2["lng"]
                        -
                        p1["lng"]
                    )
                    *
                    blend
                )
            )

            return {
                "lat": lat,
                "lng": lng
            }

        travelled += dist

    return coords[-1]


# =========================================================
# SEGMENTS
# =========================================================

def get_segment(
    route_coords,
    current_stop,
    next_stop
):

    target = (
        f"{current_stop}-{next_stop}"
    )

    for segment in route_coords:

        if segment["name"] == target:

            return segment["coords"]

    return []


# =========================================================
# ACTIVE SEGMENT
# =========================================================

def get_active_segment(
    timetable,
    current_full
):

    current_seconds = (
        full_to_seconds(
            current_full
        )
    )

    stops = list(
        timetable.keys()
    )

    for i in range(
        len(stops) - 1
    ):

        start_stop = stops[i]

        end_stop = stops[i + 1]

        start_time = (
            hhmm_to_seconds(
                timetable[start_stop]
            )
        )

        end_time = (
            hhmm_to_seconds(
                timetable[end_stop]
            )
        )

        adjusted_current = (
            current_seconds
        )

        # midnight rollover
        if end_time < start_time:

            end_time += 86400

            if adjusted_current < start_time:

                adjusted_current += 86400

        if (
            start_time
            <=
            adjusted_current
            <=
            end_time
        ):

            duration = (
                end_time
                -
                start_time
            )

            elapsed = (
                adjusted_current
                -
                start_time
            )

            progress = (
                elapsed / duration
            )

            return {
                "current_stop": start_stop,
                "next_stop": end_stop,
                "stop_index": i,
                "progress": progress
            }

    return None


# =========================================================
# BUS PROCESSOR
# =========================================================

def process_bus(
    bus,
    current_hhmm,
    current_full
):

    active_trip = None

    active_departure = None

    for departure in (
        bus.timetable.keys()
    ):

        timetable = (
            bus.timetable[
                departure
            ]
        )

        segment = get_active_segment(
            timetable,
            current_full
        )

        if segment:

            active_trip = segment

            active_departure = departure

            break

    # inactive
    if not active_trip:

        bl = BusLocation.objects.filter(
            bus_name=bus.bus_name
        ).first()

        if bl:

            route = Routes.objects.filter(
                route_name=bus.route_name
            ).first()

            if route:

                stops = route.stopsData or []

                if stops:

                    # previous trip was takeoff
                    if bl.state == "takeoff":

                        target_stop = stops[-1]

                    # previous trip was return
                    else:

                        target_stop = stops[0]

                    bl.live_location = {
                        "lat": target_stop["lat"],
                        "lng": target_stop["lng"]
                    }

                    bl.current_stop = (
                        target_stop["name"]
                    )

                    bl.next_stop = (
                        target_stop["name"]
                    )

            bl.state = "inactive"

            bl.save()

        return

    route = (
        Routes.objects.filter(
            route_name=bus.route_name
        ).first()
    )

    if not route:
        return

    current_stop = (
        active_trip["current_stop"]
    )

    next_stop = (
        active_trip["next_stop"]
    )

    progress = (
        active_trip["progress"]
    )

    if active_departure in bus.returns:

        state = "return"

        segment_source = (
            route.stop_to_stop_coords_rev
        )

    else:

        state = "takeoff"

        segment_source = (
            route.stop_to_stop_coords
        )

    coords = get_segment(
        segment_source,
        current_stop,
        next_stop
    )

    if not coords:

        print(
            f"NO COORDS: "
            f"{current_stop}-{next_stop}"
        )

        return

    live_coord = get_live_coord(
        coords,
        progress
    )

    if live_coord is None:
        return

    bl, _ = (
        BusLocation.objects.get_or_create(
            bus_name=bus.bus_name
        )
    )

    bl.route_name = (
        bus.route_name
    )

    bl.current_stop = (
        current_stop
    )

    bl.next_stop = (
        next_stop
    )

    bl.live_location = (
        live_coord
    )

    bl.route_coords = (
        coords
    )

    bl.speed = (
        progress
    )

    bl.state = (
        state
    )

    bl.stop_index = (
        active_trip["stop_index"]
    )

    bl.prev_stop_index = (
        active_trip["stop_index"]
        -
        1
    )

    bl.save()

    print(
        f"[{bus.bus_name}] "
        f"{current_stop} -> "
        f"{next_stop} | "
        f"{round(progress * 100, 2)}%"
    )


# =========================================================
# COMMAND
# =========================================================

class Command(BaseCommand):

    help = "Bus simulation worker"

    def handle(
        self,
        *args,
        **kwargs
    ):

        print(
            "Starting simulation..."
        )   
        last_reload_date = None
        clock = SimulationClock()

        while True:
            current_date = clock.current_time.date()

            current_time = (
                clock.current_time.strftime("%H:%M")
            )

            if (
                current_time == "00:00"
                and
                last_reload_date != current_date
            ):

                print("MIDNIGHT DB RELOAD")

                try:

                    from AdminPanel.views import update_queue, delete_queue

                    queued_updates = update_queue[:]
                    update_queue.clear()

                    for q in queued_updates:

                        try:
                            q.save()
                        except Exception as e:
                            print(e)

                    queued_deletes = delete_queue[:]
                    delete_queue.clear()

                    for q in queued_deletes:

                        try:
                            q.delete()
                        except Exception as e:
                            print(e)

                    call_command("location_updater")
                    call_command("update_timetables")
                    call_command("merge_stops")
                    call_command("remove_empty_stops")
                    call_command("del_busloc_dupe")

                except Exception as e:

                    print(e)

                last_reload_date = current_date
            try:

                current_hhmm = (
                    clock.hhmm()
                )

                current_full = (
                    clock.full()
                )

                print(
                    f"\nTIME: "
                    f"{current_full}"
                )

                buses = Bus.objects.all()

                for bus in buses:

                    try:

                        process_bus(
                            bus,
                            current_hhmm,
                            current_full
                        )

                    except Exception:

                        traceback.print_exc()

                clock.tick()

            except KeyboardInterrupt:

                print(
                    "STOPPED"
                )

                break

            except Exception:

                traceback.print_exc()

                clock.tick()