from django.core.management.base import BaseCommand

from AdminPanel.models import (
    Bus,
    Routes
)


class Command(BaseCommand):

    help = "Debug route coordinate issues"

    def add_arguments(self, parser):

        parser.add_argument(
            "bus_name",
            type=str
        )

    def handle(self, *args, **kwargs):

        bus_name = kwargs["bus_name"]

        try:

            b = Bus.objects.get(
                bus_name=bus_name
            )

        except Bus.DoesNotExist:

            print("BUS NOT FOUND")
            return

        try:

            r = Routes.objects.get(
                route_name=b.route_name
            )

        except Routes.DoesNotExist:

            print("ROUTE NOT FOUND")
            return

        print("\n================ BUS ================\n")

        print("BUS NAME:")
        print(b.bus_name)

        print("\nROUTE:")
        print(b.route_name)

        print("\nTAKEOFFS:")
        print(b.take_offs)

        print("\nRETURNS:")
        print(b.returns)

        print("\nTIMETABLE:")
        print(b.timetable)

        print("\n================ ROUTE ================\n")

        print("\nSTOPS DATA:")
        for s in r.stopsData:
            print(s)

        print("\nFORWARD COORDS:")
        for s in r.stop_to_stop_coords:
            print(s["name"])

        print("\nREVERSE COORDS:")
        for s in r.stop_to_stop_coords_rev:
            print(s["name"])